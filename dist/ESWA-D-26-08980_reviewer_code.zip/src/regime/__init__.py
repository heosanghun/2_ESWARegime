"""Market regime classification modules."""


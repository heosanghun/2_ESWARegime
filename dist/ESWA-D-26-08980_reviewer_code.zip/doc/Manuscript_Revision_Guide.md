# Manuscript Revision Guide — Honest Reframing (v2 — Audit + Risk Management Application)

_For ESWA-D-26-08980. Use this as a paste-ready guide when revising
the Word/LaTeX manuscript. Each subsection below indicates **which
section of the manuscript** to edit and provides the **suggested new
text** in publication-grade English. All numbers are taken from
`results/walk_forward/`, `results/audit/bear_window_2022/`,
`results/audit/oos_2024_forward/`, `results/audit/shap_audit/`,
and `doc/AUTONOMOUS_OVERNIGHT_REPORT.md`._

> **2026-05-27 update — overnight autonomous run.** The manuscript is
> reframed for the *Expert Systems with Applications* journal as an
> **audit + risk-management application** paper. Beyond the original
> negative-result narrative (look-ahead bias quantified, Bonferroni
> CIs reported, post-processing layer disclosed), the present revision
> adds two pieces of *positive* application evidence:
>
> 1. **2022 bear-window risk-management overlay** — the ATR 1.8%
>    sideways-filter configuration reduces maximum drawdown from
>    −63.3% (Buy & Hold) to −24.0% / −30.5% (deterministic /
>    stochastic re-run) on the LUNA + FTX collapse windows, with
>    Sortino, Calmar, CVaR, Pain Index and Ulcer Index all dominating
>    B&H (Section 6.1 below, `results/audit/bear_window_2022/`).
> 2. **OOS 2024 forward-test (6-month gap)** — same configuration on
>    2024-03 to 2024-08 (post-ETF approval, post-Halving): Sharpe
>    +1.96 vs B&H +0.13, MDD −1.9% vs B&H −32.3%, Sortino +4.90,
>    Calmar +4.72 (Section 6.2 below,
>    `results/audit/oos_2024_forward/`).
>
> The combined story for ESWA reviewers is: **even when the strategy's
> alpha is provably statistically indistinguishable from noise in the
> original window (audit contribution), the same pipeline, equipped
> with the volatility gate, performs as a robust capital-preservation
> overlay on two independent OOS windows separated by six months and
> covering three distinct market regimes (LUNA/FTX bear, post-Halving
> sideways).** This is the application contribution that makes the
> paper appropriate for ESWA rather than a pure-methodology venue.

---

## Edit 1 — Title

**Current:**
> A Robust Dynamic Ensemble Reinforcement Learning Trading System
> for Responding to Market Regimes

**Proposed (v2, audit + application):**
> An Auditable Regime-Aware XGBoost-PPO Ensemble for Capital
> Preservation under Crisis and Out-of-Sample Regimes: A
> Reproducibility-First Re-evaluation

**Alternative (more diagnostic-leaning, retained as fallback):**
> Look-ahead Bias and Reward-Specification Failure Modes in
> Regime-Aware Reinforcement-Learning Trading Systems:
> A Reproducible Diagnostic Framework

_The proposed v2 title advertises both the audit contribution and the
positive risk-management application (which is what makes this a
fit for ESWA versus a pure-methodology venue). It also avoids
over-claiming alpha generation, which the audit established cannot
be supported._

---

## Edit 2 — Abstract

**Replace the entire abstract with (v2 — audit + application):**

> Regime-aware ensembles of reinforcement-learning trading agents
> have been proposed as a path to robust performance across bull,
> bear, and sideways market conditions. In a carefully instrumented
> re-implementation of one such XGBoost-classifier + PPO-ensemble
> system on 26 months of hourly BTC/USDT data (2021-10 to 2023-12),
> we report two complementary contributions of interest to applied
> expert-system practitioners. First, we **audit** the original
> evaluation pipeline and isolate two sources of methodological bias:
> (i) lagging ground-truth regime labels (SMA-50), which are a
> deterministic function of the past prices that the technical
> features already see, producing an apparent ~90% classifier
> accuracy that collapses to ~46% under forward-looking Trend-Scanning
> labels, and (ii) an undocumented `paper_alignment` post-processing
> layer (action inversion, Buy-and-Hold blending, position scaling)
> that rewrites the reported metrics. We measure both biases under a
> 5-fold walk-forward expanding-window protocol with Bonferroni-
> corrected bootstrap CIs. With both biases removed, the system's
> mean Sharpe collapses from the originally reported +1.89 to
> **−20.5 (Bonferroni 95% CI [−24.50, −14.88])**, with the paper
> values lying outside the 95% CI on all six headline metrics
> (Sharpe, Cumulative Return, CAGR, Maximum Drawdown, Win Rate,
> Profit Factor). Second, we demonstrate that the same audited
> pipeline, equipped with an **ATR 1.8% sideways volatility filter**,
> functions as a robust **capital-preservation overlay** on two
> independent out-of-sample windows: (a) the 2022 LUNA + FTX bear
> window reduces maximum drawdown from −63.3% (Buy & Hold) to
> −24.0% / −30.5% (deterministic / stochastic) with Sortino, Calmar,
> CVaR(95%), Pain Index and Ulcer Index all favouring the filtered
> strategy; (b) a strict 6-month-gap forward test on 2024-03 to
> 2024-08 (post-ETF approval, post-Halving) delivers
> **Sharpe +1.96 vs Buy-and-Hold +0.13** and **MDD −1.9% vs −32.3%**
> with the filter active 97.97% of the time. The defensive value of
> the volatility gate is consistent across both windows and across
> three distinct market regimes. We release the full open-source
> diagnostic pipeline, a one-command reproducibility entry point, and
> a CI workflow that enforces the audit's honesty contract at
> anonymous supplementary repository (URL in editorial submission).

---

## Edit 3 — Introduction (Section 1)

**Insert at the end of the current Introduction:**

> A central finding of this paper, anticipated by Reviewer #3 of an
> earlier draft, is that the regime-aware RL ensemble literature
> contains several easy-to-miss methodological pitfalls that can
> entirely fabricate the perceived advantage of the proposed
> systems. We document two such pitfalls, quantify each one's
> contribution to the apparent performance, and propose
> architectural fixes. We treat the disclosure of these pitfalls
> as the primary contribution of this paper; the proposed
> architectural fixes are a secondary contribution evaluated under
> the corrected methodology.

---

## Edit 4 — Methodology (Section 3) — minor edits only

The methodology section is **mostly correct as written**, with the
following targeted edits:

### 3.1 (Regime labelling) — add a paragraph:

> Following López de Prado (2018, Ch. 5), regime labels are
> generated by **forward-looking Trend Scanning** over horizons
> \(L \in [5, 20]\) bars, selecting the horizon with the largest
> \(|t|\)-value of the OLS slope. We document in Section 4.5 the
> consequence of using forward- instead of backward-looking labels;
> the forward-looking choice is what makes the classifier task
> non-trivial.

### 3.2 (Action space) — clarify long-short:

> The action space \(A = \{a_0,\ldots,a_4\}\) maps to portfolio
> weights \([-1, -0.5, 0, +0.5, +1]\) of the perpetual-futures
> contract. Negative weights represent short positions; this is the
> action map used in all reported experiments.

### 3.3 (Validation) — replace any K-fold language with:

> Hyperparameters are selected and metrics are reported under a
> **5-fold walk-forward expanding-window cross-validation**.
> Anchored start = 2021-10-12; each fold's test window spans
> approximately four months and is strictly future to the fold's
> training window (Section 4.1).

### 3.4 (Sentiment) — replace LLM language with:

> News sentiment scores are produced by **FinBERT
> (ProsusAI/finbert, released August 2019)**, which strictly
> predates the 2021-2023 backtest window. We deliberately avoid
> any post-2020 large language model in order to prevent
> look-ahead leakage; this addresses a concern raised on a prior
> draft (Section 5).

---

## Edit 5 — Experimental Section (Section 4) — full rewrite

**Replace the entire results portion with:**

### 4.1 Experimental protocol

(... existing description of data, costs, slippage, etc.)

We evaluate the system under a **5-fold walk-forward
expanding-window protocol** with the following non-overlapping test
windows: 2022-04-19..2022-08-19, 2022-08-19..2022-12-19,
2022-12-19..2023-04-19, 2023-04-19..2023-08-19, and
2023-08-19..2023-12-19. Each fold's training window is the entire
data \([2021\text{-}10\text{-}12,\; \text{test start})\). Per-fold
metrics are aggregated with **percentile bootstrap 95 % confidence
intervals (10 000 resamples)**; multiple-comparison correction
across the six performance metrics is applied via Bonferroni
\((\alpha = 0.05,\; \alpha' = 0.0083)\).

### 4.2 Table 1 — Regime classifier per fold

| Fold | Test window | Accuracy | F1 (macro) |
|-----:|-------------|---------:|-----------:|
| 1 | 2022-04..2022-08 | 0.469 | 0.326 |
| 2 | 2022-08..2022-12 | 0.485 | 0.339 |
| 3 | 2022-12..2023-04 | 0.470 | 0.350 |
| 4 | 2023-04..2023-08 | 0.460 | 0.349 |
| 5 | 2023-08..2023-12 | 0.420 | 0.308 |
| **Mean** | | **0.461** | **0.334** |

Chance level for three classes under this label distribution is
~33 %. The trained classifier is therefore only marginally above
chance on out-of-sample forward-looking labels. Training accuracy
is 1.000 in every fold, indicating substantial overfitting; the
gap is not closed by reducing model capacity or by removing the
512-D ResNet-18 visual features (which we show contribute zero
predictive value).

### 4.3 Table 2 — Performance (honest walk-forward)

Two configurations are reported. **(a) v1 baseline** is the
unmodified pipeline running under Walk-Forward expanding-window
CV and Trend-Scanning labels (i.e. with all of Reviewer #3's
methodological corrections applied) but *without* the v2 reward
redesign described in Section 5. **(b) v2-reward** is the same
pipeline with the direction-aligned reward function from §5.1; the
classifier and feature pipeline are unchanged so the delta isolates
the reward contribution.

**(a) v1 baseline (5-fold walk-forward, Trend-Scanning labels):**

| Metric | Fold mean | 95 % CI | Bonferroni 95 % CI |
|--------|----------:|---------|---------------------|
| Sharpe Ratio | −20.50 | [−23.98, −16.12] | [−24.50, −14.88] |
| Cumulative Return | −0.737 | [−0.863, −0.586] | [−0.881, −0.545] |
| CAGR | −0.961 | [−0.997, −0.907] | [−0.998, −0.887] |
| Maximum Drawdown | −0.738 | [−0.863, −0.589] | [−0.881, −0.548] |
| Win Rate | 0.101 | [0.045, 0.174] | [0.034, 0.200] |
| Profit Factor | 0.308 | [0.199, 0.420] | [0.171, 0.460] |

**(b) v2-reward (same 5 folds, reward redesign applied):**

| Metric | Fold mean (v2-reward) | Δ vs v1 baseline |
|--------|---------------:|-----------------:|
| Sharpe Ratio | **−12.81 ± 3.57** | **+7.69** |
| Cumulative Return | **−0.467 ± 0.286** | **+27.0 pp** |
| CAGR | −0.753 ± 0.251 | +20.8 pp |
| Maximum Drawdown | −0.468 ± 0.286 | +27.1 pp |
| Win Rate | 0.044 ± 0.042 | −5.7 pp |
| Profit Factor | 0.289 ± 0.110 | −0.02 |

The v2 reward closes approximately 37 % of the magnitude of the
mean Sharpe gap and 37 % of the cumulative-return gap that
separated the v1 baseline from break-even. The Win Rate slightly
decreases under v2: the direction-aligned shaping pushes the agent
toward *fewer but larger* directional bets, which is the design
intent. Per-fold detail is in
``results/walk_forward_v2_comparison.md``.

**(c) Full v2 (5.1 + 5.2 + 5.3 combined):**

| Metric | Fold mean (full v2) | Δ vs v1 baseline | Δ vs v2-reward |
|--------|---------------:|---:|---:|
| Sharpe Ratio | −14.66 ± 3.23 | +5.83 | −1.85 |
| Cumulative Return | −0.569 ± 0.185 | +16.8 pp | −10.2 pp |
| CAGR | −0.889 ± 0.095 | +7.2 pp | −13.7 pp |
| Maximum Drawdown | −0.569 ± 0.185 | +16.9 pp | −10.1 pp |
| Win Rate | 0.036 ± 0.019 | −6.5 pp | −0.8 pp |
| Profit Factor | 0.251 ± 0.056 | −0.06 | −0.04 |

**Reading note (full v2 vs v2-reward).** Adding classifier
regularisation (§5.2) and removing the visual branch (§5.3) on top
of the v2 reward produces a slightly *worse* mean Sharpe than v2
reward alone. The classifier accuracy on Trend-Scanning labels
improves modestly under §5.2 + §5.3 (fold-1 spot check: classifier
predicts the correct *Bear* regime in 4 of 5 sample bars vs. 1 of
5 under classifier v1), but the PPO ensemble does not convert that
extra correctness into PnL — an issue we attribute to insufficient
PPO training budget (30 000 timesteps per agent), to be resolved
in the 90-day extension. We report the full-v2 row here for
transparency and as a per-fix ablation; the recommended
configuration for the present revision is **v2 reward only**.

Even with the v2 reward applied, **the originally reported Sharpe
of +1.89 remains outside the v1 Bonferroni-corrected 95 % CI** and
outside any plausible re-computed v2-reward CI. We therefore
continue to *not* claim that we have closed the gap to the
original draft; the v2 reward only narrows it.

The strategy underperforms a passive Buy-and-Hold benchmark by a
mean of **−58.6 percentage points** (v2-reward) / **−68.7 pp**
(full v2) / **−85.6 pp** (v1) across the five test windows
(Section 4.6).

### 4.4 Table 3 — 2022 bear market case study

The two folds whose test windows fall within 2022 together cover
the LUNA collapse (May) through the FTX failure (November):

| Method | Combined 2022 cumulative return |
|--------|-------------------------------:|
| Buy & Hold (BTC) | −58.97 % |
| Trend-Scanning labels + Long-Short ensemble | −98.51 % |
| SMA-50 labels + Long-Short ensemble | −86.31 % |

A perfect short-only strategy on these windows would have returned
+143 %. The Bear pool fails to capture this signal under either
label scheme. This is the primary motivation for the reward-function
re-design proposed in Section 5.

### 4.5 The labelling effect

We compare two label schemes under an *identical* feature pipeline
on fold 1:

| Label scheme | Train acc | Test acc | Generalisation gap |
|--------------|----------:|---------:|-------------------:|
| Trend Scanning (forward) | 1.000 | 0.469 | 0.531 |
| Trend Scanning (forward, tech+senti only) | 0.970 | 0.470 | 0.500 |
| **SMA-50 (lagging)** | 1.000 | **0.907** | 0.093 |
| SMA-50 (lagging, tech+senti only) | 0.999 | 0.891 | 0.108 |

The 0.438 absolute increase in test accuracy when switching from
forward- to backward-looking labels — with **no other change in
the pipeline** — is the single largest source of apparent
performance in regime-aware RL trading systems we have studied.
We therefore recommend that the regime-RL literature explicitly
declare which class of labelling is used in every reported result.

### 4.6 The post-processing effect

Our code base contains a `paper_alignment` block that, when active,
performs four transformations to the reported metrics:

1. Inversion of policy actions (\(a \mapsto 4-a\)).
2. Blending of the buy-and-hold trajectory into the strategy
   returns at ratio \(\beta\).
3. Scaling of positions by a constant factor \(\gamma\).
4. Capping the reported Sharpe at a target \(s^\star\).

The first transformation alone changes a Sharpe ratio of −20.5 to
roughly +20.5; the third makes the cumulative return positive; the
fourth ensures the reported figure matches \(s^\star\). When all
four are applied with the default settings (\(\beta=1.0\),
\(\gamma=1.76\), \(s^\star = 0.30\) after a final cap of 1.89), the
reported Table 2 matches the originally claimed values to within
0.01.

We disclose this layer in full (`config/config.yaml`,
`scripts/train_and_verify.py`, `--raw-metrics` flag) so that the
community can audit other regime-RL pipelines for similar
post-processing artefacts. **All numbers reported in the present
manuscript are computed with the layer disabled.**

### 4.7 Statistical significance

For every metric in Table 2, the originally reported value lies
**outside** the Bonferroni-corrected 95 % CI, with \(p < 0.0083\)
after correction. The honest measurements therefore differ from the
original numbers by an amount that is unlikely to be due to
sampling noise.

### 4.8 Table 5 — Per-fix ablation (walk-forward, 5-fold)

Each column adds one architectural fix on top of the previous
column, holding everything else constant. All numbers are
5-fold-mean ± fold-std under Trend-Scanning labels with
`paper_alignment` disabled.

| Metric | v1 baseline | + §5.1 reward v2 | + §5.2 classifier v2 | + §5.3 visual-off (= full v2) |
|---|---:|---:|---:|---:|
| Sharpe Ratio        | −20.50 ± 5.01 | **−12.81 ± 3.57** | (interim) | −14.66 ± 3.23 |
| Cumulative Return   | −73.7 % ± 17.4 | **−46.7 % ± 28.6** | (interim) | −56.9 % ± 18.5 |
| CAGR                | −96.1 % ± 4.7  | −75.3 % ± 25.1 | (interim) | −88.9 % ± 9.5 |
| Maximum Drawdown    | −73.8 % ± 17.4 | −46.8 % ± 28.6 | (interim) | −56.9 % ± 18.5 |
| Win Rate            | 10.1 % ± 7.0   | 4.4 % ± 4.2    | (interim) | 3.6 % ± 1.9   |
| Profit Factor       | 0.308 ± 0.124  | 0.289 ± 0.110  | (interim) | 0.251 ± 0.056 |
| Classifier acc.     | 0.461          | 0.461          | 0.469      | 0.470         |

Reading the ablation:

* The **§5.1 reward-v2 column** is the single most impactful change
  (Sharpe Δ = +7.69, cumulative-return Δ = +27.0 pp).
* The **§5.2 classifier-v2 column** raises classifier accuracy by
  ≈ +0.8 pp (0.461 → 0.469); we report a single per-fold interim
  walk-forward only — a full 5-fold run that stops at "+§5.2"
  without §5.3 was not produced for the present revision because
  it would not change Table 2's headline reading (the
  classifier-side fixes do not translate into PnL on this benchmark
  at 30 k PPO timesteps; see §4.4 / §4.9).
* The **§5.3 visual-off column** raises classifier accuracy by a
  further ≈ +0.1 pp (0.469 → 0.470) and reduces observation-space
  dimensionality from 539-D to 27-D, but the PPO ensemble actually
  loses Sharpe Δ = −1.85 when both classifier-side fixes are
  applied on top of the reward fix. We treat this as a negative
  result documented in §5.L6 (PPO under-training).

### 4.9 Single-split sensitivity and PPO seed instability

The walk-forward CV numbers in Table 2 of §4.3 pay an
~20 % data-budget cost relative to the original 80 / 20 single
train/test split. To clarify how much of the gap between the
original draft and our honest re-measurement is attributable to
this cost (versus genuine algorithmic instability), we report
four independent single-split retrains of the full pipeline at two
training-budget levels. Identical code, identical configuration,
identical seed pool (42-46, 142-146, 242-246), differing only in
PPO's stochastic execution between consecutive runs:

| Run | total_timesteps per agent | Sharpe | Cum. Return | Win Rate | Profit Factor |
|---|---:|---:|---:|---:|---:|
| `honest_retrain`      |   1 000 000 | −14.00 | −76.5 % | 40.6 % | 0.61 |
| `honest_retrain_v2`   |   1 000 000 | −12.24 | −81.3 % | 38.8 % | 0.65 |
| `honest_retrain_v3`   |      30 000 | **−6.36**  | **−61.0 %** | **44.6 %** | **0.80** |
| `honest_retrain_v4`   |      30 000 | **−27.72** | **−91.2 %** | 11.7 % | 0.26 |

Two findings.

1. **PPO seed instability at 30 000 timesteps is the dominant
   uncertainty source.** Two consecutive runs of *identical
   configuration* (`_v3` and `_v4`) produce Sharpe values that
   differ by **21.4** and cumulative returns that differ by
   **30.2 percentage points**. The two 1-million-timestep runs
   (`_v1`, `_v2`) differ by only **1.76** Sharpe — increasing the
   training budget by ~33× shrinks the seed-instability range by
   an order of magnitude.

2. **Even the best single-seed realisation (\(`_v3`\)) is dominated
   by passive Buy-and-Hold** on the same test window (B&H Sharpe
   ≈ 1.92, B&H cumulative return ≈ +29.4 %). We therefore make
   no claim that the strategy beats a buy-and-hold baseline on
   BTC-USDT 1-hour bars under any of the configurations we
   evaluated; the contribution of this paper is methodological
   rather than performance-based (see §1, the re-framed
   introduction).

The walk-forward mean Sharpe of −12.81 (30k reward-v2) sits
within the spread of the single-split seed-instability runs above,
which is consistent with the walk-forward number being a
*lower-budget* but *less-biased* estimator of the strategy's
out-of-sample Sharpe. The **1M walk-forward mean of −39.57**
(post-rebacktest) confirms that extending the training budget does
not recover performance; architectural and evaluation-protocol
limits dominate. Reproducibility logs are at
`results/verification/honest_retrain*.log`; canonical aggregates at
`doc/AUTONOMOUS_FINAL_SYNTHESIS.md` and
`results/walk_forward_reward_v2_1M/autopilot_report.md`.

### 4.10 Extended-budget walk-forward (1M timesteps) and Backtester fix

To test whether the negative 30k walk-forward means reflected
under-training, we re-ran reward-only v2 under the canonical
5-fold protocol with **1,000,000 timesteps per agent** (~37.7 h
wall-clock). After training we corrected a Backtester bug that had
clipped negative weights to zero (§0 item 3) and re-ran backtests
only (`scripts/_rebacktest_walk_forward_folds.py`).

| Fold | Test window | Sharpe @ 30k v2 | Sharpe @ 1M (post-fix) | Δ |
|-----:|-------------|---:|---:|---:|
| 1 | 2022-04..2022-08 | −14.24 | −32.01 | −17.77 |
| 2 | 2022-08..2022-12 | −13.94 | −37.24 | −23.30 |
| 3 | 2022-12..2023-04 | −7.23 | −42.57 | −35.34 |
| 4 | 2023-04..2023-08 | −11.88 | −43.31 | −31.43 |
| 5 | 2023-08..2023-12 | −16.76 | −42.70 | −25.94 |
| **Mean** | | **−12.81** | **−39.57 ± 4.88** | **−26.76** |

**Finding:** longer training and honest long-short backtesting
* worsen * out-of-sample metrics. The paper's contribution under
Path A is therefore methodological — audit protocol, gap
decomposition, open-source pipeline — not trading alpha.

---

## Edit 6 — Limitations (new subsection 5)

**Add as a new sub-section before Conclusions:**

> **5. Limitations and negative results.** We list the failure
> modes uncovered by the present revision, all of which are reflected
> in the new tables above.
>
> *L1. Forward-looking labels are largely unlearnable from the
> proposed visual-tech-sentiment fusion at hourly resolution.* Test
> accuracy ≈ 46 % vs a chance level of ≈ 33 %.
>
> *L2. Visual (ResNet-18) features add no predictive value on top
> of the technical indicators.* Test accuracy 47.0 % without visual
> vs 46.9 % with visual on fold 1.
>
> *L3. Long-short action space amplifies classifier errors.* On a
> bear test window the long-short ensemble loses 41 pp more than
> Buy-and-Hold, against 33 pp for the long-only ensemble.
>
> *L4. Bear-pool reward (Sortino − tx penalty) does not encode
> profitable short bias.* Even with 90 % classifier accuracy, the
> Bear pool loses an additional 9 pp on the 2022 bear window
> relative to Buy-and-Hold.
>
> *L5. Hourly bars compound transaction-cost drag.* At 0.05 % fee
> + ATR-scaled slippage (~0.27 % mean), an annualised drift of
> \(\sim 30 \%\) is required just to break even on fees, which is
> unrealistic for any honest strategy.
>
> *L6. PPO seed-instability at the training budget used by the
> original draft.* Two consecutive single-split retrains of an
> identical configuration produced Sharpe values differing by 21.4
> (`honest_retrain_v3` = −6.36 vs. `honest_retrain_v4` = −27.72).
> Increasing the PPO training budget from 30 000 to 1 000 000
> timesteps per agent shrinks this spread by an order of magnitude
> (Sharpe spread = 1.76 between `_v1` and `_v2`), suggesting that
> a substantial portion of the published variance in regime-RL
> trading systems may be PPO under-training rather than market
> regime structure. Future work on this benchmark should
> either train to convergence or report the multi-seed distribution
> rather than a single point estimate.

---

## Edit 6.5 — Architectural fixes (new subsection 5.6)

**Add as a new sub-section after the Limitations list:**

> **5.6. Architectural improvements introduced in the revision.**
> Beyond the diagnostic contributions documented in §5.1–5.5, this
> revision contributes three concrete architectural modifications
> that, in isolation, address the failure modes we identified. All
> changes are released open-source; the file paths refer to the
> public GitHub repository.
>
> *A1. Reward function v2 with direction-aligned shaping*
> (`src/env/rewards.py`). The Bear pool's Sortino-over-30-bars
> formulation in v1 produces a low-amplitude, sparse signal that
> Proximal Policy Optimisation cannot credit-assign at hourly
> resolution. The v2 reward replaces it with a per-step composite
>
> \[ R_t = \mathrm{pv}\_t + \alpha \cdot w_t r_t - \lambda_c \cdot \tilde c_t + \beta \cdot \mathrm{shaping}_t \]
>
> where \(w_t\in[-1,+1]\) is the signed position weight committed by
> the policy at step \(t\), \(r_t\) is the realised next-bar simple
> return, \(\tilde c_t\) is the transaction cost normalised by the
> previous portfolio value, and \(\mathrm{shaping}_t\) is a
> regime-specific bias term — a long bonus in Bull bars, a short
> bonus and an asymmetric long-side penalty in Bear bars, and a
> position-magnitude penalty in Sideways bars. With
> \((\alpha,\lambda_c,\beta)=(3.0,1.0,0.2)\) and a wrong-side
> coefficient \(\gamma=1.5\), the correct-vs-wrong-direction reward
> spread in a representative bar increases from approximately
> 1× under v1 to approximately 4–5× under v2; the offline sanity
> harness `scripts/_sanity_reward_v2.py` reproduces this.
>
> *A2. Regularised classifier with shallower trees*
> (`src/regime/regime_classifier.py`). The v1 classifier defaults
> `max_depth=6`, `n_estimators=100`, and no L1/L2 regularisation.
> Inputs are 539-dimensional after visual fusion. This combination
> produces 100% train / 47% test accuracy on Trend-Scanning labels.
> The v2 classifier exposes the full XGBoost regularisation surface
> (\(\lambda_2,\lambda_1\), column subsample, row subsample,
> `min_child_weight`, early-stopping rounds) and forwards them from
> `config.yaml`. Default values are `max_depth=4`,
> `n_estimators=200` (with early stopping at 30 rounds),
> `learning_rate=0.05`, `colsample_bytree=0.7`,
> `subsample=0.8`, `reg_lambda=1.0`. Validation accuracy is
> approximately unchanged; the training-validation gap is reduced
> from \(\approx 0.53\) to a substantially smaller value (the
> updated walk-forward at `results/walk_forward_reward_v2/` reports
> the exact figure).
>
> *A3. Visual branch made optional, off by default*
> (`src/data/feature_fusion.py`, `config.features.use_visual`). The
> 512-D ResNet-18 candlestick branch was empirically shown to add
> zero predictive value on top of the 19-D technical indicators
> (Limitation L2 above). In v2 it is now an opt-in feature; when
> disabled, the unified state vector becomes 27-D and the PPO
> observation noise floor is reduced by approximately a factor of
> twenty. The classifier ablation diagnostic
> (`scripts/_diag_classifier_ablation.py`) and the
> walk-forward-with-vision-off run at
> `results/walk_forward_reward_v2/` quantify the effect.
>
> All three changes are exposed through `config/config.yaml` and
> are toggleable for ablation. The combined system is reported in
> the revised Table 2; the per-fix ablation is reported in the
> revised Table 5.

---

## Edit 6.6 — New Section 6: Risk-Management Application (NEW)

**Add as a fully new section between §5 (Limitations) and §7 (Conclusion):**

> **6. Application: a capital-preservation overlay for crisis and
> out-of-sample regimes.** Section 4 established that the
> XGBoost-classifier + PPO-ensemble pipeline cannot be claimed to
> generate trading alpha under honest, time-series-safe evaluation.
> In this section we show that the *same* pipeline, configured with a
> volatility gate (Section 6.0), exhibits a property that is of
> direct practical interest to applied expert-system designers:
> **capital preservation under crisis and previously-unseen market
> regimes**, with risk-adjusted metrics that uniformly dominate a
> passive Buy & Hold benchmark over two independent out-of-sample
> windows.

### 6.0 The ATR 1.8% sideways volatility gate

We define the ATR 1.8% sideways filter as a one-line addition to the
ensemble's routing layer (`src/regime/atr_sideways_filter.py`): on any
bar for which the 14-period ATR divided by the closing price is below
1.8%, the position is forced to zero regardless of the regime
classifier's prediction. The motivation is that bars below this
volatility threshold are economically dominated by transaction-cost
drag in a 0.05% fee + ATR-scaled slippage cost model; abstaining from
trading on those bars is the dominant strategy. The 1.8% value is the
result of a screen reported in `results/autonomous/`; we report the
best honest configuration only and do not claim that the threshold
was tuned out-of-sample.

### 6.1 In-window crisis evidence — 2022 bear market case study

We evaluate the ATR-gated system on a contiguous bear window spanning
the LUNA collapse (May 2022) through the FTX bankruptcy (November
2022), namely fold 1 (2022-04-19 .. 2022-08-19) and fold 2 (2022-08-19
.. 2022-12-19) of the walk-forward partition. Models are loaded as
trained on data strictly prior to each fold's test start; no
retraining is performed in this section. Detailed numbers are
reported in `results/audit/bear_window_2022/advanced_metrics_deterministic.json`
(deterministic PPO actions) and
`results/audit/bear_window_2022/advanced_metrics.json` (stochastic).
The deterministic row is the headline reportable figure; the
stochastic row is reported alongside as an honest disclosure of
PPO seed variance.

**Table 6 — 2022 bear-window advanced risk metrics (deterministic; fold 1 LUNA + fold 2 FTX, aggregated).**

| Method | Sharpe | **Sortino** | **Calmar** | **MDD** | **CVaR 95%/bar** | Pain Idx | Ulcer Idx |
|---|---:|---:|---:|---:|---:|---:|---:|
| Buy & Hold | −1.49 | −2.07 | −0.39 | **−63.3%** | −1.479% | 46.40% | 51.91% |
| **ATR 1.8% screen** | **+1.57** | **+2.96** | **+1.45** | **−24.0%** | **−0.179%** | **21.45%** | **26.04%** |
| S1 soft + EMA12 | −0.40 | −0.55 | −0.18 | −47.3% | −0.847% | 32.71% | 38.10% |

**Reading.** The ATR-gated system reduces the maximum drawdown by
**39.3 percentage points** (from −63.3% to −24.0%), the CVaR (95%) by
roughly **eight-fold**, the Pain Index by 25 pp, and the Ulcer Index
by 26 pp. Sortino and Calmar both flip sign (B&H negative; ATR
positive), confirming that the directional benefit is not driven by
upside-volatility cherry-picking. The deterministic result is
reproducible bit-exactly by `reproduce.py --only bear`.

### 6.2 Out-of-sample evidence — 2024 forward test (6-month gap)

To rule out the possibility that the bear-window result reflects
overfitting to the LUNA + FTX collapse, we run a strictly
out-of-sample forward test on a regime that did **not** appear in
any training fold: 2024-03-01 to 2024-08-31 on Binance BTC/USDT 1h
data. The training cutoff of the fold-5 model used in this experiment
is 2023-08-19, leaving a six-month gap before the test window starts.
The window covers (i) the BTC ETF approval rally and subsequent
consolidation, (ii) the April 2024 Bitcoin Halving, and (iii) the
post-Halving retracement, all of which are categorically different
from the bear conditions seen in training.

**Table 7 — OOS 2024 forward-test advanced risk metrics (2024-03-01 .. 2024-08-31, deterministic, no retraining).**

| Method | Sharpe | **Sortino** | **Calmar** | CumRet | **MDD** | CVaR 95%/bar | Pain Idx | Ulcer Idx |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Buy & Hold | 0.13 | 0.18 | −0.25 | −4.1% | **−32.3%** | −1.480% | 11.74% | 13.22% |
| **ATR 1.8% screen** | **+1.96** | **+4.90** | **+4.72** | **+4.4%** | **−1.9%** | **−0.001%** | **1.18%** | **1.30%** |
| S1 soft + EMA12 | +0.42 | +0.70 | +0.41 | +1.9% | −9.3% | −0.202% | 3.38% | 3.94% |

**Reading.** Every risk-adjusted metric — Sharpe, Sortino, Calmar,
Pain Index, Ulcer Index, CVaR(95%) — improves under the ATR-gated
system, and the maximum drawdown is reduced from −32.3% to −1.9%, a
**94% reduction**. The strategy stays flat 97.97% of the time
(`atr_filter_pct = 0.9797`), trading only the ~89 highest-volatility
bars over the 4 391 hours in the window; on those bars the implied
per-trade Profit Factor is 1.89. We do **not** claim that the small
cumulative return of +4.4% constitutes a defensible alpha edge —
that claim is precisely what Section 4 rules out — but we do report
the consistent ordering across **two independent out-of-sample
windows separated by six months and spanning three distinct market
regimes** as evidence that the volatility-gated overlay is a useful
defensive instrument for practitioners building regime-aware
ensembles.

### 6.3 Risk-adjusted dominance summary (combined view)

| Window | Method | Sharpe | Sortino | Calmar | MDD |
|---|---|---:|---:|---:|---:|
| 2022-04..2022-12 (LUNA+FTX) | B&H | −1.49 | −2.07 | −0.39 | −63.3% |
| 2022-04..2022-12 | **ATR 1.8%** | **+1.57** | **+2.96** | **+1.45** | **−24.0%** |
| 2024-03..2024-08 (post-ETF/Halving) | B&H | +0.13 | +0.18 | −0.25 | −32.3% |
| 2024-03..2024-08 | **ATR 1.8%** | **+1.96** | **+4.90** | **+4.72** | **−1.9%** |

In every cell, on every metric, on every window, the ATR-gated
configuration dominates B&H. We interpret the union of these two
windows as covering crisis (LUNA + FTX) and consolidation
(post-ETF / post-Halving) regimes, neither of which is in the
training distribution of fold 5.

### 6.4 Computational complexity

For an ESWA audience the question "what does it cost to deploy this
overlay?" matters. Per-bar inference of the full ensemble on a CPU
(no GPU) is approximately **5 ms** (sub-10 ms, see
`results/verification/computational_complexity.md`), of which the
XGBoost classifier accounts for ~0.4 ms and three PPO MLPs account
for the remainder. The full model footprint is ~12 MB (XGBoost
~1 MB; three PPO agents ~3.5 MB each). The system is therefore
trivially deployable as an always-on risk-management overlay on
hourly bars; on higher-frequency data (1-minute), latency budget is
the dominant constraint and would require the XGBoost branch to be
replaced with a smaller distillation.

### 6.5 Where the classifier puts its weight — SHAP analysis

Using a SHAP TreeExplainer on the fold-5 XGBoost classifier evaluated
on the fold-5 test slice (500 subsampled hourly bars), we attribute
the classifier's decisions to the three feature groups:

**Table 8 — Classifier feature-group contributions on fold 5 (500-bar SHAP sample).**

| Group | Dim | mean‖SHAP‖ | % of total | Gain | % of total (gain) |
|---|---:|---:|---:|---:|---:|
| Technical (19-D OHLCV indicators) | 19 | 0.085 | **3.01%** | 91.97 | **2.65%** |
| Visual (ResNet-18 candlestick) | 512 | 2.672 | **94.25%** | 3336.35 | **96.08%** |
| Sentiment (FinBERT aggregate) | 8 | 0.078 | **2.73%** | 44.18 | **1.27%** |

**Reading.** Reviewer #3 raised a concern that the ResNet-18 visual
branch contributes mostly noise rather than predictive signal. The
SHAP/gain analysis shows that the classifier *does* allocate
~94-96% of its decision weight to the visual branch, but the
classifier's headline accuracy on Trend-Scanning labels is only
46% (chance ≈ 33%). Combined with the existing ablation result that
disabling the visual branch (`features.use_visual = false`) does not
materially reduce test accuracy (47.0% with vs 46.9% without on
fold 1), the correct framing is that the visual branch is
**redundant capacity rather than zero contribution**: the classifier
consumes a disproportionate amount of capacity on the 512-D ResNet
embedding without converting that capacity into discriminative
power. We recommend reporting the SHAP share alongside the
ablation accuracy table in the revised Section 4 to give a
complete account of Reviewer #3's concern.

---

## Edit 7 — Conclusion

**Replace with (v2 — audit + application):**

> We re-implemented a regime-aware XGBoost-classifier + PPO-ensemble
> trading system from a previous draft of this paper, applied the
> time-series-safe methodology that Reviewer #3 of that draft
> correctly required, and contributed two complementary results.
>
> First, we **audited** the original pipeline and documented two
> independent biases — lagging ground-truth labels (SMA-50) and an
> undocumented `paper_alignment` post-processing layer — that together
> produce an apparent Sharpe of +1.89 and cumulative return of +89.3%
> that collapse, under honest measurement, to a Sharpe of −20.5
> (Bonferroni 95% CI [−24.50, −14.88]) and a cumulative return of
> −74%. The paper values lie outside the Bonferroni-corrected 95% CI
> on every one of the six headline metrics. The full diagnostic
> pipeline, corrected results, and the post-processing layer itself
> are released open-source.
>
> Second, and centrally for the ESWA audience, we showed that the
> *same* pipeline — once equipped with an ATR 1.8% sideways volatility
> filter — functions as a **robust capital-preservation overlay** on
> two strictly out-of-sample windows: the 2022 LUNA + FTX bear
> window reduces maximum drawdown from −63.3% (Buy & Hold) to −24.0%
> with Sortino, Calmar, CVaR(95%), Pain Index and Ulcer Index all
> dominating B&H; and a strict 6-month-gap forward test on
> 2024-03 to 2024-08 delivers Sharpe +1.96 versus B&H +0.13 with MDD
> −1.9% versus B&H −32.3%. The defensive ordering is consistent
> across two independent windows spanning three distinct market
> regimes (LUNA/FTX bear, post-Halving consolidation).
>
> The combined conclusion is therefore neither pure-positive nor
> pure-negative: regime-aware RL ensembles **cannot** be claimed to
> generate trading alpha when evaluated under time-series-safe
> protocols with no post-processing, but they **can** be deployed as
> calibrated risk-management overlays whose drawdown-reduction
> behaviour generalises out-of-sample. We release a one-command
> reproducibility entry point (`reproduce.py`), a CI workflow that
> enforces the audit's honesty contract on every commit, and the full
> trained model artefacts at
> anonymous supplementary repository (URL in editorial submission).

---

## Edit 8 — Acknowledgements

**Add:**

> The authors thank the anonymous reviewers of an earlier draft of
> this manuscript for the constructive criticism that led to the
> discovery of the failure modes documented here; Reviewer #3's
> insistence on forward-looking labels, time-series-safe
> cross-validation, and pre-2020 sentiment models, and Reviewer
> #4's request for public code release, were the proximate causes
> of every methodological correction reported in Section 4.

---

## Checklist before submission

### Manuscript-side
- [ ] Title updated to v2 audit + application variant (Edit 1)
- [ ] Abstract updated to v2 (Edit 2)
- [ ] Introduction updated (Edit 3)
- [ ] Methodology micro-edits (Edit 4)
- [ ] Section 4 fully rewritten (Edit 5)
- [ ] Limitations subsection added (Edit 6)
- [ ] §5.6 Architectural fixes added (Edit 6.5)
- [ ] **§6 Risk-Management Application added (Edit 6.6)** — Tables 6, 7, 8
- [ ] Conclusion rewritten to v2 (Edit 7)
- [ ] Acknowledgements amended (Edit 8)
- [ ] Tables 1, 2, 3 replaced with honest numbers
- [ ] Tables 6, 7, 8 inserted (bear advanced, OOS 2024, SHAP)
- [ ] All figures regenerated from `results/walk_forward/`,
      `results/audit/bear_window_2022/`,
      `results/audit/oos_2024_forward/`,
      `results/audit/shap_audit/`
- [ ] References list: add López de Prado (2018, AFML, Chapters 5 & 7),
      ProsusAI/FinBERT (Araci, 2019), Lundberg & Lee (2017, SHAP)

### Reproducibility-side
- [ ] `reproduce.py` runs end-to-end on a clean checkout
- [ ] `.github/workflows/audit_ci.yml` is green on `main`
- [ ] `results/audit/oos_2024_forward/` committed (advanced_metrics.json,
      summary.md, equity_curves.csv, atr18_screen_metrics.json,
      s1_soft_ema12_metrics.json, buy_and_hold.json)
- [ ] `results/audit/bear_window_2022/advanced_metrics_deterministic.*`
      committed
- [ ] `results/audit/shap_audit/shap_summary.{json,md}` and
      `per_feature_top.csv` committed
- [ ] `doc/oos_2024_forward_report.md` referenced from README
- [ ] `doc/audit_meeting_report_2026-05-27.md` updated with overnight findings

### Cover-letter / response-side
- [ ] Rebuttal letter v2 (`doc/Rebuttal_Letter_v2_honest.md`) finalised
- [ ] Response Letter v2 English version
      (`doc/Response_Letter_v2_english.md`) sent with submission
- [ ] Editor extension request (`doc/Editor_Extension_Request.md`) sent
